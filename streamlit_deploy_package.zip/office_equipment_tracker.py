# office_equipment_tracker.py
# Ganti isi file ini dengan versi final dari aplikasimu.
import streamlit as st
st.title("Hello, Streamlit Cloud!")
